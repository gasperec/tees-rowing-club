import "dotenv/config";

function required(name: string): string {
  const value = process.env[name];
  if (!value && process.env.NODE_ENV === "production") {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value ?? "";
}

export const env = {
  // Secret used to sign session tokens — set any long random string.
  appSecret: required("APP_SECRET"),
  isProduction: process.env.NODE_ENV === "production",
  databaseUrl: required("DATABASE_URL"),
  // Optional: Google sign-in. Create free credentials at
  // https://console.cloud.google.com/apis/credentials
  googleClientId: process.env.GOOGLE_CLIENT_ID ?? "",
  googleClientSecret: process.env.GOOGLE_CLIENT_SECRET ?? "",
  // Optional: the first account registered with this email becomes the admin.
  adminEmail: (process.env.ADMIN_EMAIL ?? "").toLowerCase(),
};
